﻿/// <autosync enabled="true" />
/// <reference path='../lib/zeptojs/src/zepto.js' />
/// <reference path='../lib/zeptojs/src/event.js' />
/// <reference path='../lib/swiper/dist/js/swiper.js' />